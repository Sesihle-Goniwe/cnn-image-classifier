```python
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import random
import os
import pandas as pd
import cv2
import tensorflow
```


```python
pip install "numpy<2"
```


```python
train_folder = "C:/Users/keevo/OneDrive/Desktop/ACML project/archive/train"
val_folder   = "C:/Users/keevo/OneDrive/Desktop/ACML project/archive/val"
test_folder  = "C:/Users/keevo/OneDrive/Desktop/ACML project/archive/test"
```


```python
labels = ["NORMAL", "PNEUMONIA"] # each folder has two sub folder name "PNEUMONIA", "NORMAL"
IMG_SIZE = 152 # resize image I will make this 152 when doing preprocessing

def get_data_train(data_dir):
    data = []
    for label in labels:
        path = os.path.join(data_dir, label) #look for subfolders N and P
        class_num = labels.index(label) #0 for NORMAL, 1 for PNEUMONIA
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path, img), cv2.IMREAD_GRAYSCALE)#convert to grayscale
                new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))#have to make this 152
                data.append([new_array, class_num])
            except Exception as e:
                print(e)
    return np.array(data, dtype=object)
```


```python
train = get_data_train(train_folder)
test = get_data_train(test_folder)
val = get_data_train(val_folder)
```

    OpenCV(4.13.0) D:\a\opencv-python\opencv-python\opencv\modules\imgproc\src\resize.cpp:4208: error: (-215:Assertion failed) !ssize.empty() in function 'cv::resize'
    
    


```python
l = []
for i in train:
    if(i[1] == 0):
        l.append("Normal")
    else:
        l.append("Pneumonia")
        
sns.countplot(x = l) #specifically state which axis data belongs to
plt.show()
```


    
![png](output_5_0.png)
    



```python
X_train = []
y_train = []

X_val = []
y_val = []

X_test = []
y_test = []

for feature, label in train:
    X_train.append(feature)
    y_train.append(label)

for feature, label in test:
    X_test.append(feature)
    y_test.append(label)
    
for feature, label in val:
    X_val.append(feature)
    y_val.append(label)
```


```python
X_train = np.array(X_train) / 255.0
X_val = np.array(X_val) / 255.0
X_test = np.array(X_test) / 255.0
```


```python
X_train.shape
```




    (2360, 152, 152)




```python
from tensorflow.keras.preprocessing.image import ImageDataGenerator

X_train = X_train.reshape(-1, IMG_SIZE, IMG_SIZE, 1)#-1 shortcut telling NumPy to figure out number of images automatically
y_train = np.array(y_train)

datagen = ImageDataGenerator(
    rotation_range=20,      # Randomly rotate images (0-20 degrees)
    zoom_range=0.2,         # Randomly zoom in/out by 20%
    width_shift_range=0.1,  # Randomly shift images horizontally
    height_shift_range=0.1, # Randomly shift images vertically
    horizontal_flip=True,   # Randomly flip images (Normal lungs vs Pneumonia)
    fill_mode='nearest'     # How to fill empty pixels created by rotation/shifts
)
```


```python
X_val = X_val.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_val = np.array(y_val)

X_test = X_test.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_test = np.array(y_test)
```


```python
plt.figure(figsize=(10, 10))
# Take one image from your training set
sample_img = X_train[0].reshape((1, IMG_SIZE, IMG_SIZE, 1))

# Generate 9 random versions of this one image
i = 0
for batch in datagen.flow(sample_img, batch_size=1):
    plt.subplot(3, 3, i + 1)
    plt.imshow(batch[0].reshape(IMG_SIZE, IMG_SIZE), cmap='gray')
    plt.title(f"Augmented Version {i+1}")
    plt.axis('off')
    i += 1
    if i % 9 == 0:
        break
plt.show()
```


    
![png](output_11_0.png)
    



```python
import tensorflow as tf
from tensorflow.keras.layers import Flatten, Conv2D, Activation, Dense, Dropout, MaxPooling2D
from tensorflow.keras.models import Sequential
```


```python
X_train.shape
```




    (2360, 152, 152, 1)




```python
model = Sequential()

model.add(Conv2D(32, (3, 3), padding="same", input_shape=X_train.shape[1:]))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))


model.add(Flatten())
model.add(Dense(256, activation="relu"))

model.add(Dense(1))
model.add(Activation("sigmoid"))          


model.compile(loss = "binary_crossentropy",
             optimizer = "adam",
             metrics=['accuracy'])

callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=3)


history = model.fit(X_train, y_train, epochs=15, validation_data=(X_val, y_val), shuffle=True, callbacks=[callback])          
          
```

    WARNING:tensorflow:TensorFlow GPU support is not available on native Windows for TensorFlow >= 2.11. Even if CUDA/cuDNN are installed, GPU will not be used. Please use WSL2 or the TensorFlow-DirectML plugin.
    

    C:\Users\keevo\anaconda3\Lib\site-packages\keras\src\layers\convolutional\base_conv.py:113: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(activity_regularizer=activity_regularizer, **kwargs)
    

    Epoch 1/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m15s[0m 167ms/step - accuracy: 0.7398 - loss: 0.5104 - val_accuracy: 0.7200 - val_loss: 0.5466
    Epoch 2/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 165ms/step - accuracy: 0.9250 - loss: 0.2020 - val_accuracy: 0.8425 - val_loss: 0.4000
    Epoch 3/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 163ms/step - accuracy: 0.9470 - loss: 0.1369 - val_accuracy: 0.8487 - val_loss: 0.4031
    Epoch 4/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 160ms/step - accuracy: 0.9610 - loss: 0.1014 - val_accuracy: 0.8813 - val_loss: 0.3060
    Epoch 5/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 162ms/step - accuracy: 0.9695 - loss: 0.0852 - val_accuracy: 0.9087 - val_loss: 0.2359
    Epoch 6/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 158ms/step - accuracy: 0.9644 - loss: 0.0977 - val_accuracy: 0.9150 - val_loss: 0.2118
    Epoch 7/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 160ms/step - accuracy: 0.9720 - loss: 0.0729 - val_accuracy: 0.8900 - val_loss: 0.2712
    Epoch 8/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 158ms/step - accuracy: 0.9822 - loss: 0.0584 - val_accuracy: 0.9112 - val_loss: 0.2402
    Epoch 9/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 159ms/step - accuracy: 0.9758 - loss: 0.0599 - val_accuracy: 0.8788 - val_loss: 0.3837
    Epoch 10/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 158ms/step - accuracy: 0.9814 - loss: 0.0571 - val_accuracy: 0.8963 - val_loss: 0.2818
    Epoch 11/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 163ms/step - accuracy: 0.9801 - loss: 0.0521 - val_accuracy: 0.9075 - val_loss: 0.3206
    Epoch 12/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 164ms/step - accuracy: 0.9831 - loss: 0.0465 - val_accuracy: 0.9187 - val_loss: 0.2536
    Epoch 13/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m12s[0m 162ms/step - accuracy: 0.9852 - loss: 0.0334 - val_accuracy: 0.9162 - val_loss: 0.2664
    Epoch 14/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 171ms/step - accuracy: 0.9919 - loss: 0.0232 - val_accuracy: 0.8788 - val_loss: 0.4882
    Epoch 15/15
    [1m74/74[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 176ms/step - accuracy: 0.9907 - loss: 0.0260 - val_accuracy: 0.9325 - val_loss: 0.2574
    


```python
import matplotlib.pyplot as plt
accuracy = history.history['accuracy']
val_accuracy = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(len(accuracy))

plt.plot(epochs, accuracy, "b", label="trainning accuracy")
plt.plot(epochs, val_accuracy, "r", label="validation accuracy")
plt.legend()
plt.show()

plt.plot(epochs, loss, "b", label="trainning loss")
plt.plot(epochs, val_loss, "r", label="validation loss")
plt.legend()
plt.show()
```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
