```python
pip install tensorflow
```


```python


import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import random
import os
import pandas as pd
import cv2
import tensorflow


```

    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    I0000 00:00:1777282568.007395  152417 port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    I0000 00:00:1777282568.008105  152417 cudart_stub.cc:31] Could not find cuda drivers on your machine, GPU will not be used.
    I0000 00:00:1777282568.067027  152417 cpu_feature_guard.cc:227] This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
    To enable the following instructions: AVX2 AVX_VNNI FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    I0000 00:00:1777282568.880521  152417 port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    I0000 00:00:1777282568.880828  152417 cudart_stub.cc:31] Could not find cuda drivers on your machine, GPU will not be used.



```python
pip install "numpy<2"
```


```python
train_folder = "/home/vmuser/Desktop/archive/chest_xray/train"
val_folder   = "/home/vmuser/Desktop/archive/chest_xray/val"
test_folder  = "/home/vmuser/Desktop/archive/chest_xray/test"
```


```python
labels = ["NORMAL", "PNEUMONIA"] # each folder has two sub folder name "PNEUMONIA", "NORMAL"
IMG_SIZE = 152 # resize image I will make this 152 when doing preprocessing

def get_data_train(data_dir):
    data = []
    for label in labels:
        path = os.path.join(data_dir, label) #look for subfolders N and P
        class_num = labels.index(label) #0 for NORMAL, 1 for PNEUMONIA
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path, img), cv2.IMREAD_GRAYSCALE)#convert to grayscale
                new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))#have to make this 152
                data.append([new_array, class_num])
            except Exception as e:
                print(e)
    return np.array(data, dtype=object)
```


```python
train = get_data_train(train_folder)
test = get_data_train(test_folder)
val = get_data_train(val_folder)
```


```python
#need to check how many images in each class
l = []
for i in train:
    if(i[1] == 0):
        l.append("Normal")
    else:
        l.append("Pneumonia")
        
sns.countplot(x = l) #specifically state which axis data belongs to
plt.show()
```


    
![png](output_6_0.png)
    



```python
#currently our data is in pairs [immage_data, label_number] but for training
#requre images X and answers y to be separate
#This is feature label separation
#After this X will have all images and y will have label(0 or 1)
X_train = []
y_train = []

X_val = []
y_val = []

X_test = []
y_test = []

for feature, label in train:
    X_train.append(feature)
    y_train.append(label)

for feature, label in test:
    X_test.append(feature)
    y_test.append(label)
    
for feature, label in val:
    X_val.append(feature)
    y_val.append(label)
```


```python
#Normalization - scale numeric data to be between 0 or 1
#We are working with pixels, so between 0 to 255
X_train = np.array(X_train) / 255.0
X_val = np.array(X_val) / 255.0
X_test = np.array(X_test) / 255.0
```


```python
X_train.shape
#shows number images in dataset, height and width of each
```




    (5216, 152, 152)




```python
#reshape since CNNs expect a 4D tensor. Add a "Channel" at the end
#to know of image is in color(3) or grayscale(1)
#even make the labels 4D
from tensorflow.keras.preprocessing.image import ImageDataGenerator

X_train = X_train.reshape(-1, IMG_SIZE, IMG_SIZE, 1)#-1 shortcut telling NumPy to figure out number of images automatically
y_train = np.array(y_train)


# This creates a 'strategy' for transforming images during training
datagen = ImageDataGenerator(
    rotation_range=20,      # Randomly rotate images (0-20 degrees)
    zoom_range=0.2,         # Randomly zoom in/out by 20%
    width_shift_range=0.1,  # Randomly shift images horizontally
    height_shift_range=0.1, # Randomly shift images vertically
    horizontal_flip=True,   # Randomly flip images (Normal lungs vs Pneumonia)
    fill_mode='nearest'     # How to fill empty pixels created by rotation/shifts
)

X_val = X_val.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_val = np.array(y_val)

X_test = X_test.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_test = np.array(y_test)

```


```python
plt.figure(figsize=(10, 10))
# Take one image from your training set
sample_img = X_train[0].reshape((1, IMG_SIZE, IMG_SIZE, 1))

# Generate 9 random versions of this one image
i = 0
for batch in datagen.flow(sample_img, batch_size=1):
    plt.subplot(3, 3, i + 1)
    plt.imshow(batch[0].reshape(IMG_SIZE, IMG_SIZE), cmap='gray')
    plt.title(f"Augmented Version {i+1}")
    plt.axis('off')
    i += 1
    if i % 9 == 0:
        break
plt.show()
```


    
![png](output_11_0.png)
    



```python
import tensorflow as tf
from tensorflow.keras.layers import Flatten, Conv2D, Activation, Dense, Dropout, MaxPooling2D
from tensorflow.keras.models import Sequential
```


```python
X_train.shape

```




    (5216, 152, 152, 1)




```python
model = Sequential()

model.add(Conv2D(32, (3, 3), padding="same", input_shape=X_train.shape[1:]))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))


model.add(Flatten())
model.add(Dense(256, activation="relu"))

model.add(Dense(1))
model.add(Activation("sigmoid"))          


model.compile(loss = "binary_crossentropy",
             optimizer = "adam",
             metrics=['accuracy'])

callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=3)


history = model.fit(X_train, y_train, epochs=15, validation_data=(X_val, y_val), shuffle=True, callbacks=[callback])          
          
          
```

    Epoch 1/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 172ms/step - accuracy: 0.8719 - loss: 0.3070 - val_accuracy: 0.8125 - val_loss: 0.3761
    Epoch 2/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 180ms/step - accuracy: 0.9640 - loss: 0.1015 - val_accuracy: 0.6875 - val_loss: 0.5061
    Epoch 3/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 177ms/step - accuracy: 0.9664 - loss: 0.0919 - val_accuracy: 1.0000 - val_loss: 0.0785
    Epoch 4/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 179ms/step - accuracy: 0.9693 - loss: 0.0831 - val_accuracy: 0.8750 - val_loss: 0.2678
    Epoch 5/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 177ms/step - accuracy: 0.9776 - loss: 0.0622 - val_accuracy: 0.8750 - val_loss: 0.1967
    Epoch 6/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 184ms/step - accuracy: 0.9764 - loss: 0.0656 - val_accuracy: 0.8125 - val_loss: 0.3059
    Epoch 7/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 178ms/step - accuracy: 0.9799 - loss: 0.0555 - val_accuracy: 1.0000 - val_loss: 0.1180
    Epoch 8/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 177ms/step - accuracy: 0.9826 - loss: 0.0462 - val_accuracy: 1.0000 - val_loss: 0.1371
    Epoch 9/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 180ms/step - accuracy: 0.9866 - loss: 0.0388 - val_accuracy: 0.9375 - val_loss: 0.0915
    Epoch 10/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 178ms/step - accuracy: 0.9837 - loss: 0.0395 - val_accuracy: 0.9375 - val_loss: 0.2091
    Epoch 11/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 180ms/step - accuracy: 0.9898 - loss: 0.0266 - val_accuracy: 0.9375 - val_loss: 0.1682
    Epoch 12/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 185ms/step - accuracy: 0.9898 - loss: 0.0294 - val_accuracy: 1.0000 - val_loss: 0.0525
    Epoch 13/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 182ms/step - accuracy: 0.9896 - loss: 0.0280 - val_accuracy: 1.0000 - val_loss: 0.0606
    Epoch 14/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 181ms/step - accuracy: 0.9927 - loss: 0.0226 - val_accuracy: 0.9375 - val_loss: 0.1649
    Epoch 15/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 177ms/step - accuracy: 0.9935 - loss: 0.0189 - val_accuracy: 0.8750 - val_loss: 0.2172



```python
# visualization

import matplotlib.pyplot as plt
accuracy = history.history['accuracy']
val_accuracy = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(len(accuracy))

plt.plot(epochs, accuracy, "b", label="trainning accuracy")
plt.plot(epochs, val_accuracy, "r", label="validation accuracy")
plt.legend()
plt.show()

plt.plot(epochs, loss, "b", label="trainning loss")
plt.plot(epochs, val_loss, "r", label="validation loss")
plt.legend()
plt.show()
```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    



```python
##we need = 1509 for training
##need 2090 val and test 

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
