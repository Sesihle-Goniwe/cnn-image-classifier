```python
pip install tensorflow
```


```python


import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import random
import os
import pandas as pd
import cv2
import tensorflow


```

    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    I0000 00:00:1777289777.128528  195488 port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    I0000 00:00:1777289777.132823  195488 cudart_stub.cc:31] Could not find cuda drivers on your machine, GPU will not be used.
    I0000 00:00:1777289777.575470  195488 cpu_feature_guard.cc:227] This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
    To enable the following instructions: AVX2 AVX_VNNI FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    I0000 00:00:1777289778.718839  195488 port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    I0000 00:00:1777289778.720314  195488 cudart_stub.cc:31] Could not find cuda drivers on your machine, GPU will not be used.



```python
pip install "numpy<2"
```


```python
train_folder = "/home/vmuser/Desktop/archive/chest_xray/train"
val_folder   = "/home/vmuser/Desktop/archive/chest_xray/val"
test_folder  = "/home/vmuser/Desktop/archive/chest_xray/test"
```


```python
labels = ["NORMAL", "PNEUMONIA"] # each folder has two sub folder name "PNEUMONIA", "NORMAL"
IMG_SIZE = 152 # resize image I will make this 152 when doing preprocessing

def get_data_train(data_dir):
    data = []
    for label in labels:
        path = os.path.join(data_dir, label) #look for subfolders N and P
        class_num = labels.index(label) #0 for NORMAL, 1 for PNEUMONIA
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path, img), cv2.IMREAD_GRAYSCALE)#convert to grayscale
                new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))#have to make this 152
                data.append([new_array, class_num])
            except Exception as e:
                print(e)
    return np.array(data, dtype=object)
```


```python
train = get_data_train(train_folder)
test = get_data_train(test_folder)
val = get_data_train(val_folder)
```


```python
#need to check how many images in each class
l = []
for i in train:
    if(i[1] == 0):
        l.append("Normal")
    else:
        l.append("Pneumonia")
        
sns.countplot(x = l) #specifically state which axis data belongs to
plt.show()
```


    
![png](output_6_0.png)
    



```python
#currently our data is in pairs [immage_data, label_number] but for training
#requre images X and answers y to be separate
#This is feature label separation
#After this X will have all images and y will have label(0 or 1)
X_train = []
y_train = []

X_val = []
y_val = []

X_test = []
y_test = []

for feature, label in train:
    X_train.append(feature)
    y_train.append(label)

for feature, label in test:
    X_test.append(feature)
    y_test.append(label)
    
for feature, label in val:
    X_val.append(feature)
    y_val.append(label)
```


```python
#Normalization - scale numeric data to be between 0 or 1
#We are working with pixels, so between 0 to 255
X_train = np.array(X_train) / 255.0
X_val = np.array(X_val) / 255.0
X_test = np.array(X_test) / 255.0
```


```python
# X_val.shape
X_train.shape
#shows number images in dataset, height and width of each
```




    (5216, 152, 152)




```python
#reshape since CNNs expect a 4D tensor. Add a "Channel" at the end
#to know of image is in color(3) or grayscale(1)
#even make the labels 4D
from tensorflow.keras.preprocessing.image import ImageDataGenerator

X_train = X_train.reshape(-1, IMG_SIZE, IMG_SIZE, 1)#-1 shortcut telling NumPy to figure out number of images automatically
y_train = np.array(y_train)


# This creates a 'strategy' for transforming images during training
datagen = ImageDataGenerator(
    rotation_range=20,      # Randomly rotate images (0-20 degrees)
    zoom_range=0.2,         # Randomly zoom in/out by 20%
    width_shift_range=0.1,  # Randomly shift images horizontally
    height_shift_range=0.1, # Randomly shift images vertically
    horizontal_flip=True,   # Randomly flip images (Normal lungs vs Pneumonia)
    fill_mode='nearest'     # How to fill empty pixels created by rotation/shifts
)

X_val = X_val.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_val = np.array(y_val)

X_test = X_test.reshape(-1, IMG_SIZE, IMG_SIZE, 1)
y_test = np.array(y_test)

```


```python
plt.figure(figsize=(10, 10))
# Take one image from your training set
sample_img = X_train[0].reshape((1, IMG_SIZE, IMG_SIZE, 1))

# Generate 9 random versions of this one image
i = 0
for batch in datagen.flow(sample_img, batch_size=1):
    plt.subplot(3, 3, i + 1)
    plt.imshow(batch[0].reshape(IMG_SIZE, IMG_SIZE), cmap='gray')
    plt.title(f"Augmented Version {i+1}")
    plt.axis('off')
    i += 1
    if i % 9 == 0:
        break
plt.show()
```


    
![png](output_11_0.png)
    



```python
import tensorflow as tf
from tensorflow.keras.layers import Flatten, Conv2D, Activation, Dense, Dropout, MaxPooling2D
from tensorflow.keras.models import Sequential
```


```python
X_train.shape

```




    (5216, 152, 152, 1)




```python
model = Sequential()

model.add(Conv2D(32, (3, 3), padding="same", input_shape=X_train.shape[1:]))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))

model.add(Conv2D(32, (3, 3), padding="same"))
model.add(Activation("relu"))
model.add(MaxPooling2D(2, 2))
model.add(Dropout(0.2))


model.add(Flatten())
model.add(Dense(256, activation="relu"))

model.add(Dense(1))
model.add(Activation("sigmoid"))          


model.compile(loss = "binary_crossentropy",
             optimizer = "adam",
             metrics=['accuracy'])

callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=3)


history = model.fit(X_train, y_train, epochs=15, validation_data=(X_val, y_val), shuffle=True, callbacks=[callback])          
          
          
```

    /home/vmuser/anaconda3/lib/python3.12/site-packages/keras/src/layers/convolutional/base_conv.py:113: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(activity_regularizer=activity_regularizer, **kwargs)
    E0000 00:00:1777289864.544917  195488 cuda_platform.cc:52] failed call to cuInit: INTERNAL: CUDA error: Failed call to cuInit: UNKNOWN ERROR (303)


    Epoch 1/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 172ms/step - accuracy: 0.8800 - loss: 0.2704 - val_accuracy: 0.7317 - val_loss: 0.7144
    Epoch 2/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m31s[0m 189ms/step - accuracy: 0.9620 - loss: 0.1049 - val_accuracy: 0.7622 - val_loss: 0.6767
    Epoch 3/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m32s[0m 196ms/step - accuracy: 0.9632 - loss: 0.1023 - val_accuracy: 0.7774 - val_loss: 0.6689
    Epoch 4/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m34s[0m 207ms/step - accuracy: 0.9735 - loss: 0.0680 - val_accuracy: 0.7012 - val_loss: 1.0906
    Epoch 5/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m33s[0m 203ms/step - accuracy: 0.9743 - loss: 0.0671 - val_accuracy: 0.7957 - val_loss: 0.5348
    Epoch 6/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m35s[0m 213ms/step - accuracy: 0.9787 - loss: 0.0585 - val_accuracy: 0.8232 - val_loss: 0.7095
    Epoch 7/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m36s[0m 220ms/step - accuracy: 0.9816 - loss: 0.0485 - val_accuracy: 0.8445 - val_loss: 0.6137
    Epoch 8/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 181ms/step - accuracy: 0.9841 - loss: 0.0422 - val_accuracy: 0.7591 - val_loss: 1.2572
    Epoch 9/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 180ms/step - accuracy: 0.9883 - loss: 0.0331 - val_accuracy: 0.7378 - val_loss: 1.4048
    Epoch 10/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 182ms/step - accuracy: 0.9904 - loss: 0.0279 - val_accuracy: 0.8201 - val_loss: 1.0014
    Epoch 11/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 183ms/step - accuracy: 0.9893 - loss: 0.0294 - val_accuracy: 0.8140 - val_loss: 1.1879
    Epoch 12/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 179ms/step - accuracy: 0.9881 - loss: 0.0345 - val_accuracy: 0.7104 - val_loss: 1.4264
    Epoch 13/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m29s[0m 179ms/step - accuracy: 0.9902 - loss: 0.0272 - val_accuracy: 0.7652 - val_loss: 1.3508
    Epoch 14/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m31s[0m 190ms/step - accuracy: 0.9965 - loss: 0.0114 - val_accuracy: 0.8018 - val_loss: 1.4499
    Epoch 15/15
    [1m163/163[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m30s[0m 182ms/step - accuracy: 0.9935 - loss: 0.0171 - val_accuracy: 0.8293 - val_loss: 1.2419



```python
# visualization

import matplotlib.pyplot as plt
accuracy = history.history['accuracy']
val_accuracy = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(len(accuracy))

plt.plot(epochs, accuracy, "b", label="trainning accuracy")
plt.plot(epochs, val_accuracy, "r", label="validation accuracy")
plt.legend()
plt.show()

plt.plot(epochs, loss, "b", label="trainning loss")
plt.plot(epochs, val_loss, "r", label="validation loss")
plt.legend()
plt.show()
```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    



```python
##we need = 1509 for training
##need 2090 val and test 

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
